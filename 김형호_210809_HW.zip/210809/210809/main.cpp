#include <iostream>

#include "Graph.h"

int main()
{
	CGraph<int> graph;

	graph.insert(1);
	graph.insert(2);
	graph.insert(3);
	graph.insert(4);
	graph.insert(5);
	graph.insert(6);
	graph.insert(7);
	graph.insert(8);
	graph.insert(9);

	graph.AddEdge(1, 2);
	graph.AddEdge(1, 3);

	graph.AddEdge(2, 3);
	graph.AddEdge(2, 4);
	graph.AddEdge(2, 5);

	graph.AddEdge(4, 8);

	graph.AddEdge(5, 9);

	graph.AddEdge(6, 3);

	graph.AddEdge(7, 3);

	graph.BFS(1);

	std::cout << std::endl;

	graph.DFS(1);

	return 0;
}